package Test;

import org.testng.annotations.Test;

import HelperClass.helperClass;
import PageObject.BaseClass;
import PageObject.FormFill;


public class Form extends BaseClass{

	@Test
	public void Form() throws InterruptedException
	{
		FormFill ff=new FormFill(driver);
		log.info("Form test is Started");
		ff.input();

		ff.Form();
		log.info("details are entered Successfully ");
		ff.submitButton();
		log.info("submitted Successfully");
		helperClass.captureScreenshots(driver);
		

	}

}
