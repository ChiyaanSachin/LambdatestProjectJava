package Test;

import org.testng.annotations.Test;

import HelperClass.helperClass;
import PageObject.BaseClass;
import PageObject.simpleform;

public class MessageVerify extends BaseClass {
	
	simpleform s1;
	@Test
	public void test1()
	{
		driver.get(URL);
	s1=new simpleform(driver);
	log.info("Running Test1");
	s1.option();
	log.info("testcase1 completed");
	helperClass.captureScreenshots(driver);
	
	}

}
