package Test;

import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import HelperClass.helperClass;
import PageObject.BaseClass;
import PageObject.slider;

public class Slider extends BaseClass {
	
	@Test
	public void SliderbarTest()
	{
		slider sl=new slider(driver);
		sl.DragAndDrop();
		log.info("test Started");
		sl.slider();
		log.info("test completed");
		helperClass.captureScreenshots(driver);	
	
	}
	

}
